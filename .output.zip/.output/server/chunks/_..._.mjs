import CredentialsProvider from 'next-auth/providers/credentials';
import { N as NuxtAuthHandler } from './nuxtAuthHandler.mjs';
import './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'next-auth/core';
import 'next-auth/jwt';

const _____ = NuxtAuthHandler({
  pages: {
    // Change the default behavior to use `/login` as the path for the sign-in page
    signIn: "/login"
  },
  // A secret string you define, to ensure correct encryption
  secret: process.env.AUTH_SECRET,
  callbacks: {
    // Callback when the JWT is created / updated, see https://next-auth.js.org/configuration/callbacks#jwt-callback
    jwt: async ({ token, user }) => {
      const isSignIn = user ? true : false;
      if (isSignIn) {
        token.jwt = user ? user.access_token || "" : "";
        token.id = user ? user.id || "" : "";
        token.role = user ? user.role || "" : "";
      }
      return Promise.resolve(token);
    },
    // Callback whenever session is checked, see https://next-auth.js.org/configuration/callbacks#session-callback
    session: async ({ session, token }) => {
      session.role = token.role;
      session.uid = token.id;
      return Promise.resolve(session);
    }
  },
  providers: [
    // @ts-expect-error You need to use .default here for it to work during SSR. May be fixed via Vite at some point
    CredentialsProvider.default({
      // The name to display on the sign in form (e.g. 'Sign in with...')
      name: "Credentials",
      // The credentials is used to generate a suitable form on the sign in page.
      // You can specify whatever fields you are expecting to be submitted.
      // e.g. domain, username, password, 2FA token, etc.
      // You can pass any HTML attribute to the <input> tag through the object.
      credentials: {
        email: {
          label: "Email",
          type: "text",
          placeholder: "(hint: jsmith)"
        },
        password: {
          label: "Password",
          type: "password",
          placeholder: "(hint: hunter2)"
        }
      },
      async authorize(credentials) {
        const body = {
          email: credentials == null ? void 0 : credentials.email,
          password: credentials == null ? void 0 : credentials.password
        };
        const user = await $fetch("/api/auth/me", {
          method: "POST",
          body
        });
        if (user) {
          return user;
        } else {
          console.error(
            "Warning: Malicious login attempt registered, bad credentials provided"
          );
          return null;
        }
      }
    })
  ]
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
