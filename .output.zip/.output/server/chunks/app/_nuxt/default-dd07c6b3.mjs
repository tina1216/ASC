import { _ as __nuxt_component_0 } from './nuxt-link-92569608.mjs';
import { e as useAuth, d as useRequestHeaders } from '../server.mjs';
import { defineComponent, computed, withAsyncContext, mergeProps, unref, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-7843bd59.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderSlot } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'tailwind-merge';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "default",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { status, signOut } = useAuth();
    const loggedIn = computed(() => status.value === "authenticated");
    const headers = useRequestHeaders(["cookie"]);
    const { data: token } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/auth/token", { headers }, "$i9bCpVDU6M")), __temp = await __temp, __restore(), __temp);
    const isAdmin = computed(() => {
      var _a;
      return ((_a = token.value) == null ? void 0 : _a.role) === "ADMIN";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-12 bg-gray-100 w-full h-full min-h-screen flex flex-col items-center" }, _attrs))}><div class="mb-12"><h1><span class="font-bold">Eduscholar</span></h1></div><div class="flex flex-row justify-center flex-grow"><div class="mr-4 p-8 bg-white rounded-md min-w-[20ch] flex flex-col">`);
      if (!unref(loggedIn)) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/login" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Log In`);
            } else {
              return [
                createTextVNode("Log In")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div><h3>Profile</h3>`);
        _push(ssrRenderComponent(_component_NuxtLink, { href: "/" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h3${_scopeId}>Scholarships</h3>`);
            } else {
              return [
                createVNode("h3", null, "Scholarships")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/applications" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h3${_scopeId}>Applications</h3>`);
            } else {
              return [
                createVNode("h3", null, "Applications")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div style="${ssrRenderStyle(unref(isAdmin) ? null : { display: "none" })}">`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/applications/create" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h3${_scopeId}>Create</h3>`);
            } else {
              return [
                createVNode("h3", null, "Create")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><hr class="mt-5"><button class="mt-5"><h3>Log out</h3></button></div>`);
      }
      _push(`</div><div class="p-12 bg-white rounded-md w-[100ch] flex flex-wrap"><div class="flex flex-col">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-dd07c6b3.mjs.map
