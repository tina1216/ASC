import { defineComponent, ref, computed, provide, onMounted, onUnmounted, watchEffect, nextTick, useSSRContext, withAsyncContext, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, inject, toRef, toRaw, mergeProps, resolveComponent, renderSlot, createTextVNode, toDisplayString, Fragment, renderList, Transition } from 'vue';
import { twMerge, twJoin } from 'tailwind-merge';
import { c as checkbox, t as table, k as kbd, d as dropdown, u as useUI, _ as __nuxt_component_1$1, o as omit, g as get } from './ui.config-c2fe1eb9.mjs';
import { y, w as w$1, h, o as o$1, c as c$2, u as u$2, l, H as H$1, t, b, d as p$1, p as p$2, N as N$1, f as p, e as u, x, a as a$1, g as o$2, v, k as N, n as _, j as useFormGroup, _ as __nuxt_component_2, i as usePopper, O as O$1 } from './useFormGroup-1db827b9.mjs';
import { m as mergeConfig, a as appConfig, d as useRequestHeaders, _ as _export_sfc } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrLooseContain, ssrGetDynamicModelProps, ssrRenderAttr, ssrRenderClass, ssrRenderSlot, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as __nuxt_component_0$2, a as __nuxt_component_0$1$1 } from './Button-bf5fb701.mjs';
import { L as upperFirst, a as defu } from '../../nitro/node-server.mjs';
import { u as useFetch } from './fetch-7843bd59.mjs';
import '@vueuse/core';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'requrl';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './nuxt-link-92569608.mjs';

var Y = ((l2) => (l2[l2.Open = 0] = "Open", l2[l2.Closed = 1] = "Closed", l2))(Y || {}), Z = ((l2) => (l2[l2.Pointer = 0] = "Pointer", l2[l2.Other = 1] = "Other", l2))(Z || {});
function ee(r) {
  requestAnimationFrame(() => requestAnimationFrame(r));
}
let A = Symbol("MenuContext");
function O(r) {
  let b2 = inject(A, null);
  if (b2 === null) {
    let l2 = new Error(`<${r} /> is missing a parent <Menu /> component.`);
    throw Error.captureStackTrace && Error.captureStackTrace(l2, O), l2;
  }
  return b2;
}
let Me = defineComponent({ name: "Menu", props: { as: { type: [Object, String], default: "template" } }, setup(r, { slots: b2, attrs: l$1 }) {
  let I = ref(1), e = ref(null), f = ref(null), s = ref([]), g = ref(""), d = ref(null), o$12 = ref(1);
  function t2(a2 = (i) => i) {
    let i = d.value !== null ? s.value[d.value] : null, u2 = O$1(a2(s.value.slice()), (v2) => o$1(v2.dataRef.domRef)), n = i ? u2.indexOf(i) : null;
    return n === -1 && (n = null), { items: u2, activeItemIndex: n };
  }
  let p2 = { menuState: I, buttonRef: e, itemsRef: f, items: s, searchQuery: g, activeItemIndex: d, activationTrigger: o$12, closeMenu: () => {
    I.value = 1, d.value = null;
  }, openMenu: () => I.value = 0, goToItem(a$1$1, i, u2) {
    let n = t2(), v2 = x(a$1$1 === a$1.Specific ? { focus: a$1.Specific, id: i } : { focus: a$1$1 }, { resolveItems: () => n.items, resolveActiveIndex: () => n.activeItemIndex, resolveId: (M) => M.id, resolveDisabled: (M) => M.dataRef.disabled });
    g.value = "", d.value = v2, o$12.value = u2 != null ? u2 : 1, s.value = n.items;
  }, search(a2) {
    let u2 = g.value !== "" ? 0 : 1;
    g.value += a2.toLowerCase();
    let v2 = (d.value !== null ? s.value.slice(d.value + u2).concat(s.value.slice(0, d.value + u2)) : s.value).find((x2) => x2.dataRef.textValue.startsWith(g.value) && !x2.dataRef.disabled), M = v2 ? s.value.indexOf(v2) : -1;
    M === -1 || M === d.value || (d.value = M, o$12.value = 1);
  }, clearSearch() {
    g.value = "";
  }, registerItem(a2, i) {
    let u2 = t2((n) => [...n, { id: a2, dataRef: i }]);
    s.value = u2.items, d.value = u2.activeItemIndex, o$12.value = 1;
  }, unregisterItem(a2) {
    let i = t2((u2) => {
      let n = u2.findIndex((v2) => v2.id === a2);
      return n !== -1 && u2.splice(n, 1), u2;
    });
    s.value = i.items, d.value = i.activeItemIndex, o$12.value = 1;
  } };
  return y([e, f], (a2, i) => {
    var u2;
    p2.closeMenu(), w$1(i, h.Loose) || (a2.preventDefault(), (u2 = o$1(e)) == null || u2.focus());
  }, computed(() => I.value === 0)), provide(A, p2), c$2(computed(() => u$2(I.value, { [0]: l.Open, [1]: l.Closed }))), () => {
    let a2 = { open: I.value === 0, close: p2.closeMenu };
    return H$1({ ourProps: {}, theirProps: r, slot: a2, slots: b2, attrs: l$1, name: "Menu" });
  };
} }), Re = defineComponent({ name: "MenuButton", props: { disabled: { type: Boolean, default: false }, as: { type: [Object, String], default: "button" }, id: { type: String, default: () => `headlessui-menu-button-${t()}` } }, setup(r, { attrs: b$1, slots: l2, expose: I }) {
  let e = O("MenuButton");
  I({ el: e.buttonRef, $el: e.buttonRef });
  function f(o$2$1) {
    switch (o$2$1.key) {
      case o$2.Space:
      case o$2.Enter:
      case o$2.ArrowDown:
        o$2$1.preventDefault(), o$2$1.stopPropagation(), e.openMenu(), nextTick(() => {
          var t2;
          (t2 = o$1(e.itemsRef)) == null || t2.focus({ preventScroll: true }), e.goToItem(a$1.First);
        });
        break;
      case o$2.ArrowUp:
        o$2$1.preventDefault(), o$2$1.stopPropagation(), e.openMenu(), nextTick(() => {
          var t2;
          (t2 = o$1(e.itemsRef)) == null || t2.focus({ preventScroll: true }), e.goToItem(a$1.Last);
        });
        break;
    }
  }
  function s(o2) {
    switch (o2.key) {
      case o$2.Space:
        o2.preventDefault();
        break;
    }
  }
  function g(o$12) {
    r.disabled || (e.menuState.value === 0 ? (e.closeMenu(), nextTick(() => {
      var t2;
      return (t2 = o$1(e.buttonRef)) == null ? void 0 : t2.focus({ preventScroll: true });
    })) : (o$12.preventDefault(), e.openMenu(), ee(() => {
      var t2;
      return (t2 = o$1(e.itemsRef)) == null ? void 0 : t2.focus({ preventScroll: true });
    })));
  }
  let d = b(computed(() => ({ as: r.as, type: b$1.type })), e.buttonRef);
  return () => {
    var i;
    let o$12 = { open: e.menuState.value === 0 }, { id: t2, ...p2 } = r, a2 = { ref: e.buttonRef, id: t2, type: d.value, "aria-haspopup": "menu", "aria-controls": (i = o$1(e.itemsRef)) == null ? void 0 : i.id, "aria-expanded": e.menuState.value === 0, onKeydown: f, onKeyup: s, onClick: g };
    return H$1({ ourProps: a2, theirProps: p2, slot: o$12, attrs: b$1, slots: l2, name: "MenuButton" });
  };
} }), he = defineComponent({ name: "MenuItems", props: { as: { type: [Object, String], default: "div" }, static: { type: Boolean, default: false }, unmount: { type: Boolean, default: true }, id: { type: String, default: () => `headlessui-menu-items-${t()}` } }, setup(r, { attrs: b2, slots: l$1, expose: I }) {
  let e = O("MenuItems"), f = ref(null);
  I({ el: e.itemsRef, $el: e.itemsRef }), p$1({ container: computed(() => o$1(e.itemsRef)), enabled: computed(() => e.menuState.value === 0), accept(t2) {
    return t2.getAttribute("role") === "menuitem" ? NodeFilter.FILTER_REJECT : t2.hasAttribute("role") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
  }, walk(t2) {
    t2.setAttribute("role", "none");
  } });
  function s(t2) {
    var p2;
    switch (f.value && clearTimeout(f.value), t2.key) {
      case o$2.Space:
        if (e.searchQuery.value !== "")
          return t2.preventDefault(), t2.stopPropagation(), e.search(t2.key);
      case o$2.Enter:
        if (t2.preventDefault(), t2.stopPropagation(), e.activeItemIndex.value !== null) {
          let i = e.items.value[e.activeItemIndex.value];
          (p2 = o$1(i.dataRef.domRef)) == null || p2.click();
        }
        e.closeMenu(), _(o$1(e.buttonRef));
        break;
      case o$2.ArrowDown:
        return t2.preventDefault(), t2.stopPropagation(), e.goToItem(a$1.Next);
      case o$2.ArrowUp:
        return t2.preventDefault(), t2.stopPropagation(), e.goToItem(a$1.Previous);
      case o$2.Home:
      case o$2.PageUp:
        return t2.preventDefault(), t2.stopPropagation(), e.goToItem(a$1.First);
      case o$2.End:
      case o$2.PageDown:
        return t2.preventDefault(), t2.stopPropagation(), e.goToItem(a$1.Last);
      case o$2.Escape:
        t2.preventDefault(), t2.stopPropagation(), e.closeMenu(), nextTick(() => {
          var a2;
          return (a2 = o$1(e.buttonRef)) == null ? void 0 : a2.focus({ preventScroll: true });
        });
        break;
      case o$2.Tab:
        t2.preventDefault(), t2.stopPropagation(), e.closeMenu(), nextTick(() => v(o$1(e.buttonRef), t2.shiftKey ? N.Previous : N.Next));
        break;
      default:
        t2.key.length === 1 && (e.search(t2.key), f.value = setTimeout(() => e.clearSearch(), 350));
        break;
    }
  }
  function g(t2) {
    switch (t2.key) {
      case o$2.Space:
        t2.preventDefault();
        break;
    }
  }
  let d = p$2(), o$2$1 = computed(() => d !== null ? (d.value & l.Open) === l.Open : e.menuState.value === 0);
  return () => {
    var u2, n;
    let t2 = { open: e.menuState.value === 0 }, { id: p2, ...a2 } = r, i = { "aria-activedescendant": e.activeItemIndex.value === null || (u2 = e.items.value[e.activeItemIndex.value]) == null ? void 0 : u2.id, "aria-labelledby": (n = o$1(e.buttonRef)) == null ? void 0 : n.id, id: p2, onKeydown: s, onKeyup: g, role: "menu", tabIndex: 0, ref: e.itemsRef };
    return H$1({ ourProps: i, theirProps: a2, slot: t2, attrs: b2, slots: l$1, features: N$1.RenderStrategy | N$1.Static, visible: o$2$1.value, name: "MenuItems" });
  };
} }), ye = defineComponent({ name: "MenuItem", inheritAttrs: false, props: { as: { type: [Object, String], default: "template" }, disabled: { type: Boolean, default: false }, id: { type: String, default: () => `headlessui-menu-item-${t()}` } }, setup(r, { slots: b2, attrs: l2, expose: I }) {
  let e = O("MenuItem"), f = ref(null);
  I({ el: f, $el: f });
  let s = computed(() => e.activeItemIndex.value !== null ? e.items.value[e.activeItemIndex.value].id === r.id : false), g = p(f), d = computed(() => ({ disabled: r.disabled, get textValue() {
    return g();
  }, domRef: f }));
  onMounted(() => e.registerItem(r.id, d)), onUnmounted(() => e.unregisterItem(r.id)), watchEffect(() => {
    e.menuState.value === 0 && s.value && e.activationTrigger.value !== 0 && nextTick(() => {
      var n, v2;
      return (v2 = (n = o$1(f)) == null ? void 0 : n.scrollIntoView) == null ? void 0 : v2.call(n, { block: "nearest" });
    });
  });
  function o$12(n) {
    if (r.disabled)
      return n.preventDefault();
    e.closeMenu(), _(o$1(e.buttonRef));
  }
  function t2() {
    if (r.disabled)
      return e.goToItem(a$1.Nothing);
    e.goToItem(a$1.Specific, r.id);
  }
  let p2 = u();
  function a$1$1(n) {
    p2.update(n);
  }
  function i(n) {
    p2.wasMoved(n) && (r.disabled || s.value || e.goToItem(a$1.Specific, r.id, 0));
  }
  function u2(n) {
    p2.wasMoved(n) && (r.disabled || s.value && e.goToItem(a$1.Nothing));
  }
  return () => {
    let { disabled: n } = r, v2 = { active: s.value, disabled: n, close: e.closeMenu }, { id: M, ...x2 } = r;
    return H$1({ ourProps: { id: M, ref: f, role: "menuitem", tabIndex: n === true ? void 0 : -1, "aria-disabled": n === true ? true : void 0, disabled: void 0, onClick: o$12, onFocus: t2, onPointerenter: a$1$1, onMouseenter: a$1$1, onPointermove: i, onMousemove: i, onPointerleave: u2, onMouseleave: u2 }, theirProps: { ...l2, ...x2 }, slot: v2, attrs: l2, slots: b2, name: "MenuItem" });
  };
} });
let _id = 0;
function uid() {
  return `nuid-${_id++}`;
}
const config$3 = mergeConfig(appConfig.ui.strategy, appConfig.ui.checkbox, checkbox);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  inheritAttrs: false,
  props: {
    id: {
      type: String,
      // A default value is needed here to bind the label
      default: () => uid()
    },
    value: {
      type: [String, Number, Boolean, Object],
      default: null
    },
    modelValue: {
      type: [Boolean, Array],
      default: null
    },
    name: {
      type: String,
      default: null
    },
    disabled: {
      type: Boolean,
      default: false
    },
    checked: {
      type: Boolean,
      default: false
    },
    indeterminate: {
      type: Boolean,
      default: false
    },
    help: {
      type: String,
      default: null
    },
    label: {
      type: String,
      default: null
    },
    required: {
      type: Boolean,
      default: false
    },
    color: {
      type: String,
      default: () => config$3.default.color,
      validator(value) {
        return appConfig.ui.colors.includes(value);
      }
    },
    inputClass: {
      type: String,
      default: ""
    },
    class: {
      type: [String, Object, Array],
      default: void 0
    },
    ui: {
      type: Object,
      default: void 0
    }
  },
  emits: ["update:modelValue", "change"],
  setup(props, { emit }) {
    const { ui, attrs } = useUI("checkbox", toRef(props, "ui"), config$3, toRef(props, "class"));
    const { emitFormChange, color, name, inputId } = useFormGroup(props);
    const toggle = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    const onChange = (event) => {
      emit("change", event);
      emitFormChange();
    };
    const inputClass = computed(() => {
      return twMerge(twJoin(
        ui.value.base,
        ui.value.rounded,
        ui.value.background,
        ui.value.border,
        ui.value.ring.replaceAll("{color}", color.value),
        ui.value.color.replaceAll("{color}", color.value)
      ), props.inputClass);
    });
    return {
      // eslint-disable-next-line vue/no-dupe-keys
      ui,
      attrs,
      toggle,
      inputId,
      // eslint-disable-next-line vue/no-dupe-keys
      name,
      // eslint-disable-next-line vue/no-dupe-keys
      inputClass,
      onChange
    };
  }
});
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  let _temp0;
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: _ctx.ui.wrapper
  }, _attrs))}><div class="flex items-center h-5"><input${ssrRenderAttrs((_temp0 = mergeProps({
    id: _ctx.inputId,
    checked: Array.isArray(_ctx.toggle) ? ssrLooseContain(_ctx.toggle, _ctx.value) : _ctx.toggle,
    name: _ctx.name,
    required: _ctx.required,
    value: _ctx.value,
    disabled: _ctx.disabled,
    indeterminate: _ctx.indeterminate,
    type: "checkbox",
    class: ["form-checkbox", _ctx.inputClass]
  }, _ctx.attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, _ctx.toggle))))}></div>`);
  if (_ctx.label || _ctx.$slots.label) {
    _push(`<div class="ms-3 text-sm"><label${ssrRenderAttr("for", _ctx.inputId)} class="${ssrRenderClass(_ctx.ui.label)}">`);
    ssrRenderSlot(_ctx.$slots, "label", {}, () => {
      _push(`${ssrInterpolate(_ctx.label)}`);
    }, _push, _parent);
    if (_ctx.required) {
      _push(`<span class="${ssrRenderClass(_ctx.ui.required)}">*</span>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</label>`);
    if (_ctx.help) {
      _push(`<p class="${ssrRenderClass(_ctx.ui.help)}">${ssrInterpolate(_ctx.help)}</p>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/@nuxt/ui/dist/runtime/components/forms/Checkbox.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$3]]);
const config$2 = mergeConfig(appConfig.ui.strategy, appConfig.ui.table, table);
function defaultComparator(a2, z) {
  return a2 === z;
}
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  components: {
    UButton: __nuxt_component_0$2,
    UIcon: __nuxt_component_1$1,
    UCheckbox: __nuxt_component_0$1
  },
  inheritAttrs: false,
  props: {
    modelValue: {
      type: Array,
      default: null
    },
    by: {
      type: [String, Function],
      default: () => defaultComparator
    },
    rows: {
      type: Array,
      default: () => []
    },
    columns: {
      type: Array,
      default: null
    },
    columnAttribute: {
      type: String,
      default: "label"
    },
    sort: {
      type: Object,
      default: () => ({})
    },
    sortButton: {
      type: Object,
      default: () => config$2.default.sortButton
    },
    sortAscIcon: {
      type: String,
      default: () => config$2.default.sortAscIcon
    },
    sortDescIcon: {
      type: String,
      default: () => config$2.default.sortDescIcon
    },
    loading: {
      type: Boolean,
      default: false
    },
    loadingState: {
      type: Object,
      default: () => config$2.default.loadingState
    },
    emptyState: {
      type: Object,
      default: () => config$2.default.emptyState
    },
    class: {
      type: [String, Object, Array],
      default: void 0
    },
    ui: {
      type: Object,
      default: void 0
    }
  },
  emits: ["update:modelValue"],
  setup(props, { emit, attrs: $attrs }) {
    const { ui, attrs } = useUI("table", toRef(props, "ui"), config$2, toRef(props, "class"));
    const columns = computed(() => {
      var _a, _b;
      return (_b = props.columns) != null ? _b : Object.keys(omit((_a = props.rows[0]) != null ? _a : {}, ["click"])).map((key) => ({ key, label: upperFirst(key), sortable: false }));
    });
    const sort = ref(defu({}, props.sort, { column: null, direction: "asc" }));
    const rows = computed(() => {
      var _a;
      if (!((_a = sort.value) == null ? void 0 : _a.column)) {
        return props.rows;
      }
      const { column, direction } = sort.value;
      return props.rows.slice().sort((a2, b2) => {
        const aValue = a2[column];
        const bValue = b2[column];
        if (aValue === bValue) {
          return 0;
        }
        if (direction === "asc") {
          return aValue < bValue ? -1 : 1;
        } else {
          return aValue > bValue ? -1 : 1;
        }
      });
    });
    const selected = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    const indeterminate = computed(() => selected.value && selected.value.length > 0 && selected.value.length < props.rows.length);
    const emptyState = computed(() => {
      if (props.emptyState === null)
        return null;
      return { ...ui.value.default.emptyState, ...props.emptyState };
    });
    const loadingState = computed(() => {
      if (props.loadingState === null)
        return null;
      return { ...ui.value.default.loadingState, ...props.loadingState };
    });
    function compare(a2, z) {
      if (typeof props.by === "string") {
        const property = props.by;
        return (a2 == null ? void 0 : a2[property]) === (z == null ? void 0 : z[property]);
      }
      return props.by(a2, z);
    }
    function isSelected(row) {
      if (!props.modelValue) {
        return false;
      }
      return selected.value.some((item) => compare(toRaw(item), toRaw(row)));
    }
    function onSort(column) {
      if (sort.value.column === column.key) {
        const direction = !column.direction || column.direction === "asc" ? "desc" : "asc";
        if (sort.value.direction === direction) {
          sort.value = defu({}, props.sort, { column: null, direction: "asc" });
        } else {
          sort.value.direction = sort.value.direction === "asc" ? "desc" : "asc";
        }
      } else {
        sort.value = { column: column.key, direction: column.direction || "asc" };
      }
    }
    function onSelect(row) {
      if (!$attrs.onSelect) {
        return;
      }
      $attrs.onSelect(row);
    }
    function selectAllRows() {
      props.rows.forEach((row) => {
        if (selected.value.some((item) => compare(toRaw(item), toRaw(row)))) {
          return;
        }
        $attrs.onSelect ? $attrs.onSelect(row) : selected.value.push(row);
      });
    }
    function onChange(event) {
      if (event.target.checked) {
        selectAllRows();
      } else {
        selected.value = [];
      }
    }
    function getRowData(row, rowKey, defaultValue = "Failed to get cell value") {
      return get(row, rowKey, defaultValue);
    }
    return {
      // eslint-disable-next-line vue/no-dupe-keys
      ui,
      attrs,
      // eslint-disable-next-line vue/no-dupe-keys
      sort,
      // eslint-disable-next-line vue/no-dupe-keys
      columns,
      // eslint-disable-next-line vue/no-dupe-keys
      rows,
      selected,
      indeterminate,
      // eslint-disable-next-line vue/no-dupe-keys
      emptyState,
      // eslint-disable-next-line vue/no-dupe-keys
      loadingState,
      isSelected,
      onSort,
      onSelect,
      onChange,
      getRowData
    };
  }
});
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_UCheckbox = __nuxt_component_0$1;
  const _component_UButton = __nuxt_component_0$2;
  const _component_UIcon = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: _ctx.ui.wrapper
  }, _ctx.attrs, _attrs))}><table class="${ssrRenderClass([_ctx.ui.base, _ctx.ui.divide])}"><thead class="${ssrRenderClass(_ctx.ui.thead)}"><tr class="${ssrRenderClass(_ctx.ui.tr.base)}">`);
  if (_ctx.modelValue) {
    _push(`<th scope="col" class="${ssrRenderClass(_ctx.ui.checkbox.padding)}">`);
    _push(ssrRenderComponent(_component_UCheckbox, {
      checked: _ctx.indeterminate || _ctx.selected.length === _ctx.rows.length,
      indeterminate: _ctx.indeterminate,
      "aria-label": "Select all",
      onChange: _ctx.onChange
    }, null, _parent));
    _push(`</th>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<!--[-->`);
  ssrRenderList(_ctx.columns, (column, index) => {
    _push(`<th scope="col" class="${ssrRenderClass([_ctx.ui.th.base, _ctx.ui.th.padding, _ctx.ui.th.color, _ctx.ui.th.font, _ctx.ui.th.size, column.class])}">`);
    ssrRenderSlot(_ctx.$slots, `${column.key}-header`, {
      column,
      sort: _ctx.sort,
      onSort: _ctx.onSort
    }, () => {
      if (column.sortable) {
        _push(ssrRenderComponent(_component_UButton, mergeProps({ ..._ctx.ui.default.sortButton, ..._ctx.sortButton }, {
          icon: !_ctx.sort.column || _ctx.sort.column !== column.key ? _ctx.sortButton.icon || _ctx.ui.default.sortButton.icon : _ctx.sort.direction === "asc" ? _ctx.sortAscIcon : _ctx.sortDescIcon,
          label: column[_ctx.columnAttribute],
          onClick: ($event) => _ctx.onSort(column)
        }), null, _parent));
      } else {
        _push(`<span>${ssrInterpolate(column[_ctx.columnAttribute])}</span>`);
      }
    }, _push, _parent);
    _push(`</th>`);
  });
  _push(`<!--]--></tr></thead><tbody class="${ssrRenderClass(_ctx.ui.tbody)}">`);
  if (_ctx.loadingState && _ctx.loading) {
    _push(`<tr><td${ssrRenderAttr("colspan", _ctx.columns.length + (_ctx.modelValue ? 1 : 0))}>`);
    ssrRenderSlot(_ctx.$slots, "loading-state", {}, () => {
      _push(`<div class="${ssrRenderClass(_ctx.ui.loadingState.wrapper)}">`);
      if (_ctx.loadingState.icon) {
        _push(ssrRenderComponent(_component_UIcon, {
          name: _ctx.loadingState.icon,
          class: _ctx.ui.loadingState.icon,
          "aria-hidden": "true"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="${ssrRenderClass(_ctx.ui.loadingState.label)}">${ssrInterpolate(_ctx.loadingState.label)}</p></div>`);
    }, _push, _parent);
    _push(`</td></tr>`);
  } else if (_ctx.emptyState && !_ctx.rows.length) {
    _push(`<tr><td${ssrRenderAttr("colspan", _ctx.columns.length + (_ctx.modelValue ? 1 : 0))}>`);
    ssrRenderSlot(_ctx.$slots, "empty-state", {}, () => {
      _push(`<div class="${ssrRenderClass(_ctx.ui.emptyState.wrapper)}">`);
      if (_ctx.emptyState.icon) {
        _push(ssrRenderComponent(_component_UIcon, {
          name: _ctx.emptyState.icon,
          class: _ctx.ui.emptyState.icon,
          "aria-hidden": "true"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="${ssrRenderClass(_ctx.ui.emptyState.label)}">${ssrInterpolate(_ctx.emptyState.label)}</p></div>`);
    }, _push, _parent);
    _push(`</td></tr>`);
  } else {
    _push(`<!--[-->`);
    ssrRenderList(_ctx.rows, (row, index) => {
      _push(`<tr class="${ssrRenderClass([_ctx.ui.tr.base, _ctx.isSelected(row) && _ctx.ui.tr.selected, _ctx.$attrs.onSelect && _ctx.ui.tr.active, row == null ? void 0 : row.class])}">`);
      if (_ctx.modelValue) {
        _push(`<td class="${ssrRenderClass(_ctx.ui.checkbox.padding)}">`);
        _push(ssrRenderComponent(_component_UCheckbox, {
          modelValue: _ctx.selected,
          "onUpdate:modelValue": ($event) => _ctx.selected = $event,
          value: row,
          "aria-label": "Select row",
          onClick: () => {
          }
        }, null, _parent));
        _push(`</td>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(_ctx.columns, (column, subIndex) => {
        var _a;
        _push(`<td class="${ssrRenderClass([_ctx.ui.td.base, _ctx.ui.td.padding, _ctx.ui.td.color, _ctx.ui.td.font, _ctx.ui.td.size, (_a = row[column.key]) == null ? void 0 : _a.class])}">`);
        ssrRenderSlot(_ctx.$slots, `${column.key}-data`, {
          column,
          row,
          index,
          getRowData: (defaultValue) => _ctx.getRowData(row, column.key, defaultValue)
        }, () => {
          _push(`${ssrInterpolate(_ctx.getRowData(row, column.key))}`);
        }, _push, _parent);
        _push(`</td>`);
      });
      _push(`<!--]--></tr>`);
    });
    _push(`<!--]-->`);
  }
  _push(`</tbody></table></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/@nuxt/ui/dist/runtime/components/data/Table.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const config$1 = mergeConfig(appConfig.ui.strategy, appConfig.ui.kbd, kbd);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  inheritAttrs: false,
  props: {
    value: {
      type: String,
      default: null
    },
    size: {
      type: String,
      default: () => config$1.default.size,
      validator(value) {
        return Object.keys(config$1.size).includes(value);
      }
    },
    class: {
      type: [String, Object, Array],
      default: void 0
    },
    ui: {
      type: Object,
      default: void 0
    }
  },
  setup(props) {
    const { ui, attrs } = useUI("kbd", toRef(props, "ui"), config$1);
    const kbdClass = computed(() => {
      return twMerge(twJoin(
        ui.value.base,
        ui.value.size[props.size],
        ui.value.padding,
        ui.value.rounded,
        ui.value.font,
        ui.value.background,
        ui.value.ring
      ), props.class);
    });
    return {
      // eslint-disable-next-line vue/no-dupe-keys
      ui,
      attrs,
      kbdClass
    };
  }
});
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<kbd${ssrRenderAttrs(mergeProps({ class: _ctx.kbdClass }, _ctx.attrs, _attrs))}>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, () => {
    _push(`${ssrInterpolate(_ctx.value)}`);
  }, _push, _parent);
  _push(`</kbd>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/@nuxt/ui/dist/runtime/components/elements/Kbd.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const config = mergeConfig(appConfig.ui.strategy, appConfig.ui.dropdown, dropdown);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  components: {
    HMenu: Me,
    HMenuButton: Re,
    HMenuItems: he,
    HMenuItem: ye,
    UIcon: __nuxt_component_1$1,
    UAvatar: __nuxt_component_2,
    UKbd: __nuxt_component_3,
    ULink: __nuxt_component_0$1$1
  },
  inheritAttrs: false,
  props: {
    items: {
      type: Array,
      default: () => []
    },
    mode: {
      type: String,
      default: "click",
      validator: (value) => ["click", "hover"].includes(value)
    },
    disabled: {
      type: Boolean,
      default: false
    },
    popper: {
      type: Object,
      default: () => ({})
    },
    openDelay: {
      type: Number,
      default: 0
    },
    closeDelay: {
      type: Number,
      default: 0
    },
    class: {
      type: [String, Object, Array],
      default: void 0
    },
    ui: {
      type: Object,
      default: void 0
    }
  },
  setup(props) {
    const { ui, attrs } = useUI("dropdown", toRef(props, "ui"), config, toRef(props, "class"));
    const popper = computed(() => defu(props.mode === "hover" ? { offsetDistance: 0 } : {}, props.popper, ui.value.popper));
    const [trigger, container] = usePopper(popper.value);
    const menuApi = ref(null);
    let openTimeout = null;
    let closeTimeout = null;
    const containerStyle = computed(() => {
      var _a, _b;
      const offsetDistance = ((_a = props.popper) == null ? void 0 : _a.offsetDistance) || ((_b = ui.value.popper) == null ? void 0 : _b.offsetDistance) || 8;
      return props.mode === "hover" ? { paddingTop: `${offsetDistance}px`, paddingBottom: `${offsetDistance}px` } : {};
    });
    function onMouseOver() {
      if (props.mode !== "hover" || !menuApi.value) {
        return;
      }
      if (closeTimeout) {
        clearTimeout(closeTimeout);
        closeTimeout = null;
      }
      if (menuApi.value.menuState === 0) {
        return;
      }
      openTimeout = openTimeout || setTimeout(() => {
        menuApi.value.openMenu && menuApi.value.openMenu();
        openTimeout = null;
      }, props.openDelay);
    }
    function onMouseLeave() {
      if (props.mode !== "hover" || !menuApi.value) {
        return;
      }
      if (openTimeout) {
        clearTimeout(openTimeout);
        openTimeout = null;
      }
      if (menuApi.value.menuState === 1) {
        return;
      }
      closeTimeout = closeTimeout || setTimeout(() => {
        menuApi.value.closeMenu && menuApi.value.closeMenu();
        closeTimeout = null;
      }, props.closeDelay);
    }
    return {
      // eslint-disable-next-line vue/no-dupe-keys
      ui,
      attrs,
      trigger,
      container,
      containerStyle,
      onMouseOver,
      onMouseLeave,
      omit
    };
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_HMenu = resolveComponent("HMenu");
  const _component_HMenuButton = resolveComponent("HMenuButton");
  const _component_HMenuItems = resolveComponent("HMenuItems");
  const _component_HMenuItem = resolveComponent("HMenuItem");
  const _component_ULink = __nuxt_component_0$1$1;
  const _component_UIcon = __nuxt_component_1$1;
  const _component_UAvatar = __nuxt_component_2;
  const _component_UKbd = __nuxt_component_3;
  _push(ssrRenderComponent(_component_HMenu, mergeProps({
    as: "div",
    class: _ctx.ui.wrapper
  }, _ctx.attrs, { onMouseleave: _ctx.onMouseLeave }, _attrs), {
    default: withCtx(({ open }, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_HMenuButton, {
          ref: "trigger",
          as: "div",
          disabled: _ctx.disabled,
          class: "inline-flex w-full",
          role: "button",
          onMouseover: _ctx.onMouseOver
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              ssrRenderSlot(_ctx.$slots, "default", {
                open,
                disabled: _ctx.disabled
              }, () => {
                _push3(`<button${ssrIncludeBooleanAttr(_ctx.disabled) ? " disabled" : ""}${_scopeId2}> Open </button>`);
              }, _push3, _parent3, _scopeId2);
            } else {
              return [
                renderSlot(_ctx.$slots, "default", {
                  open,
                  disabled: _ctx.disabled
                }, () => [
                  createVNode("button", { disabled: _ctx.disabled }, " Open ", 8, ["disabled"])
                ])
              ];
            }
          }),
          _: 2
        }, _parent2, _scopeId));
        if (open && _ctx.items.length) {
          _push2(`<div class="${ssrRenderClass([_ctx.ui.container, _ctx.ui.width])}" style="${ssrRenderStyle(_ctx.containerStyle)}"${_scopeId}><template>`);
          _push2(ssrRenderComponent(_component_HMenuItems, {
            class: [_ctx.ui.base, _ctx.ui.divide, _ctx.ui.ring, _ctx.ui.rounded, _ctx.ui.shadow, _ctx.ui.background, _ctx.ui.height],
            static: ""
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`<!--[-->`);
                ssrRenderList(_ctx.items, (subItems, index) => {
                  _push3(`<div class="${ssrRenderClass(_ctx.ui.padding)}"${_scopeId2}><!--[-->`);
                  ssrRenderList(subItems, (item, subIndex) => {
                    _push3(ssrRenderComponent(_component_HMenuItem, {
                      key: subIndex,
                      disabled: item.disabled
                    }, {
                      default: withCtx(({ active, disabled: itemDisabled }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_component_ULink, mergeProps(_ctx.omit(item, ["label", "slot", "icon", "iconClass", "avatar", "shortcuts", "disabled", "click"]), {
                            class: [_ctx.ui.item.base, _ctx.ui.item.padding, _ctx.ui.item.size, _ctx.ui.item.rounded, active ? _ctx.ui.item.active : _ctx.ui.item.inactive, itemDisabled && _ctx.ui.item.disabled],
                            onClick: item.click
                          }), {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                ssrRenderSlot(_ctx.$slots, item.slot || "item", { item }, () => {
                                  var _a;
                                  if (item.icon) {
                                    _push5(ssrRenderComponent(_component_UIcon, {
                                      name: item.icon,
                                      class: [_ctx.ui.item.icon.base, active ? _ctx.ui.item.icon.active : _ctx.ui.item.icon.inactive, item.iconClass]
                                    }, null, _parent5, _scopeId4));
                                  } else if (item.avatar) {
                                    _push5(ssrRenderComponent(_component_UAvatar, mergeProps({ size: _ctx.ui.item.avatar.size, ...item.avatar }, {
                                      class: _ctx.ui.item.avatar.base
                                    }), null, _parent5, _scopeId4));
                                  } else {
                                    _push5(`<!---->`);
                                  }
                                  _push5(`<span class="truncate"${_scopeId4}>${ssrInterpolate(item.label)}</span>`);
                                  if ((_a = item.shortcuts) == null ? void 0 : _a.length) {
                                    _push5(`<span class="${ssrRenderClass(_ctx.ui.item.shortcuts)}"${_scopeId4}><!--[-->`);
                                    ssrRenderList(item.shortcuts, (shortcut) => {
                                      _push5(ssrRenderComponent(_component_UKbd, { key: shortcut }, {
                                        default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                          if (_push6) {
                                            _push6(`${ssrInterpolate(shortcut)}`);
                                          } else {
                                            return [
                                              createTextVNode(toDisplayString(shortcut), 1)
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent5, _scopeId4));
                                    });
                                    _push5(`<!--]--></span>`);
                                  } else {
                                    _push5(`<!---->`);
                                  }
                                }, _push5, _parent5, _scopeId4);
                              } else {
                                return [
                                  renderSlot(_ctx.$slots, item.slot || "item", { item }, () => {
                                    var _a;
                                    return [
                                      item.icon ? (openBlock(), createBlock(_component_UIcon, {
                                        key: 0,
                                        name: item.icon,
                                        class: [_ctx.ui.item.icon.base, active ? _ctx.ui.item.icon.active : _ctx.ui.item.icon.inactive, item.iconClass]
                                      }, null, 8, ["name", "class"])) : item.avatar ? (openBlock(), createBlock(_component_UAvatar, mergeProps({ key: 1 }, { size: _ctx.ui.item.avatar.size, ...item.avatar }, {
                                        class: _ctx.ui.item.avatar.base
                                      }), null, 16, ["class"])) : createCommentVNode("", true),
                                      createVNode("span", { class: "truncate" }, toDisplayString(item.label), 1),
                                      ((_a = item.shortcuts) == null ? void 0 : _a.length) ? (openBlock(), createBlock("span", {
                                        key: 2,
                                        class: _ctx.ui.item.shortcuts
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(item.shortcuts, (shortcut) => {
                                          return openBlock(), createBlock(_component_UKbd, { key: shortcut }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(shortcut), 1)
                                            ]),
                                            _: 2
                                          }, 1024);
                                        }), 128))
                                      ], 2)) : createCommentVNode("", true)
                                    ];
                                  })
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(_component_ULink, mergeProps(_ctx.omit(item, ["label", "slot", "icon", "iconClass", "avatar", "shortcuts", "disabled", "click"]), {
                              class: [_ctx.ui.item.base, _ctx.ui.item.padding, _ctx.ui.item.size, _ctx.ui.item.rounded, active ? _ctx.ui.item.active : _ctx.ui.item.inactive, itemDisabled && _ctx.ui.item.disabled],
                              onClick: item.click
                            }), {
                              default: withCtx(() => [
                                renderSlot(_ctx.$slots, item.slot || "item", { item }, () => {
                                  var _a;
                                  return [
                                    item.icon ? (openBlock(), createBlock(_component_UIcon, {
                                      key: 0,
                                      name: item.icon,
                                      class: [_ctx.ui.item.icon.base, active ? _ctx.ui.item.icon.active : _ctx.ui.item.icon.inactive, item.iconClass]
                                    }, null, 8, ["name", "class"])) : item.avatar ? (openBlock(), createBlock(_component_UAvatar, mergeProps({ key: 1 }, { size: _ctx.ui.item.avatar.size, ...item.avatar }, {
                                      class: _ctx.ui.item.avatar.base
                                    }), null, 16, ["class"])) : createCommentVNode("", true),
                                    createVNode("span", { class: "truncate" }, toDisplayString(item.label), 1),
                                    ((_a = item.shortcuts) == null ? void 0 : _a.length) ? (openBlock(), createBlock("span", {
                                      key: 2,
                                      class: _ctx.ui.item.shortcuts
                                    }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(item.shortcuts, (shortcut) => {
                                        return openBlock(), createBlock(_component_UKbd, { key: shortcut }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(shortcut), 1)
                                          ]),
                                          _: 2
                                        }, 1024);
                                      }), 128))
                                    ], 2)) : createCommentVNode("", true)
                                  ];
                                })
                              ]),
                              _: 2
                            }, 1040, ["class", "onClick"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div>`);
                });
                _push3(`<!--]-->`);
              } else {
                return [
                  (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (subItems, index) => {
                    return openBlock(), createBlock("div", {
                      key: index,
                      class: _ctx.ui.padding
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(subItems, (item, subIndex) => {
                        return openBlock(), createBlock(_component_HMenuItem, {
                          key: subIndex,
                          disabled: item.disabled
                        }, {
                          default: withCtx(({ active, disabled: itemDisabled }) => [
                            createVNode(_component_ULink, mergeProps(_ctx.omit(item, ["label", "slot", "icon", "iconClass", "avatar", "shortcuts", "disabled", "click"]), {
                              class: [_ctx.ui.item.base, _ctx.ui.item.padding, _ctx.ui.item.size, _ctx.ui.item.rounded, active ? _ctx.ui.item.active : _ctx.ui.item.inactive, itemDisabled && _ctx.ui.item.disabled],
                              onClick: item.click
                            }), {
                              default: withCtx(() => [
                                renderSlot(_ctx.$slots, item.slot || "item", { item }, () => {
                                  var _a;
                                  return [
                                    item.icon ? (openBlock(), createBlock(_component_UIcon, {
                                      key: 0,
                                      name: item.icon,
                                      class: [_ctx.ui.item.icon.base, active ? _ctx.ui.item.icon.active : _ctx.ui.item.icon.inactive, item.iconClass]
                                    }, null, 8, ["name", "class"])) : item.avatar ? (openBlock(), createBlock(_component_UAvatar, mergeProps({ key: 1 }, { size: _ctx.ui.item.avatar.size, ...item.avatar }, {
                                      class: _ctx.ui.item.avatar.base
                                    }), null, 16, ["class"])) : createCommentVNode("", true),
                                    createVNode("span", { class: "truncate" }, toDisplayString(item.label), 1),
                                    ((_a = item.shortcuts) == null ? void 0 : _a.length) ? (openBlock(), createBlock("span", {
                                      key: 2,
                                      class: _ctx.ui.item.shortcuts
                                    }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(item.shortcuts, (shortcut) => {
                                        return openBlock(), createBlock(_component_UKbd, { key: shortcut }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(shortcut), 1)
                                          ]),
                                          _: 2
                                        }, 1024);
                                      }), 128))
                                    ], 2)) : createCommentVNode("", true)
                                  ];
                                })
                              ]),
                              _: 2
                            }, 1040, ["class", "onClick"])
                          ]),
                          _: 2
                        }, 1032, ["disabled"]);
                      }), 128))
                    ], 2);
                  }), 128))
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
          _push2(`</template></div>`);
        } else {
          _push2(`<!---->`);
        }
      } else {
        return [
          createVNode(_component_HMenuButton, {
            ref: "trigger",
            as: "div",
            disabled: _ctx.disabled,
            class: "inline-flex w-full",
            role: "button",
            onMouseover: _ctx.onMouseOver
          }, {
            default: withCtx(() => [
              renderSlot(_ctx.$slots, "default", {
                open,
                disabled: _ctx.disabled
              }, () => [
                createVNode("button", { disabled: _ctx.disabled }, " Open ", 8, ["disabled"])
              ])
            ]),
            _: 2
          }, 1032, ["disabled", "onMouseover"]),
          open && _ctx.items.length ? (openBlock(), createBlock("div", {
            key: 0,
            ref: "container",
            class: [_ctx.ui.container, _ctx.ui.width],
            style: _ctx.containerStyle,
            onMouseover: _ctx.onMouseOver
          }, [
            createVNode(Transition, mergeProps({ appear: "" }, _ctx.ui.transition), {
              default: withCtx(() => [
                createVNode(_component_HMenuItems, {
                  class: [_ctx.ui.base, _ctx.ui.divide, _ctx.ui.ring, _ctx.ui.rounded, _ctx.ui.shadow, _ctx.ui.background, _ctx.ui.height],
                  static: ""
                }, {
                  default: withCtx(() => [
                    (openBlock(true), createBlock(Fragment, null, renderList(_ctx.items, (subItems, index) => {
                      return openBlock(), createBlock("div", {
                        key: index,
                        class: _ctx.ui.padding
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(subItems, (item, subIndex) => {
                          return openBlock(), createBlock(_component_HMenuItem, {
                            key: subIndex,
                            disabled: item.disabled
                          }, {
                            default: withCtx(({ active, disabled: itemDisabled }) => [
                              createVNode(_component_ULink, mergeProps(_ctx.omit(item, ["label", "slot", "icon", "iconClass", "avatar", "shortcuts", "disabled", "click"]), {
                                class: [_ctx.ui.item.base, _ctx.ui.item.padding, _ctx.ui.item.size, _ctx.ui.item.rounded, active ? _ctx.ui.item.active : _ctx.ui.item.inactive, itemDisabled && _ctx.ui.item.disabled],
                                onClick: item.click
                              }), {
                                default: withCtx(() => [
                                  renderSlot(_ctx.$slots, item.slot || "item", { item }, () => {
                                    var _a;
                                    return [
                                      item.icon ? (openBlock(), createBlock(_component_UIcon, {
                                        key: 0,
                                        name: item.icon,
                                        class: [_ctx.ui.item.icon.base, active ? _ctx.ui.item.icon.active : _ctx.ui.item.icon.inactive, item.iconClass]
                                      }, null, 8, ["name", "class"])) : item.avatar ? (openBlock(), createBlock(_component_UAvatar, mergeProps({ key: 1 }, { size: _ctx.ui.item.avatar.size, ...item.avatar }, {
                                        class: _ctx.ui.item.avatar.base
                                      }), null, 16, ["class"])) : createCommentVNode("", true),
                                      createVNode("span", { class: "truncate" }, toDisplayString(item.label), 1),
                                      ((_a = item.shortcuts) == null ? void 0 : _a.length) ? (openBlock(), createBlock("span", {
                                        key: 2,
                                        class: _ctx.ui.item.shortcuts
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(item.shortcuts, (shortcut) => {
                                          return openBlock(), createBlock(_component_UKbd, { key: shortcut }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(shortcut), 1)
                                            ]),
                                            _: 2
                                          }, 1024);
                                        }), 128))
                                      ], 2)) : createCommentVNode("", true)
                                    ];
                                  })
                                ]),
                                _: 2
                              }, 1040, ["class", "onClick"])
                            ]),
                            _: 2
                          }, 1032, ["disabled"]);
                        }), 128))
                      ], 2);
                    }), 128))
                  ]),
                  _: 3
                }, 8, ["class"])
              ]),
              _: 3
            }, 16)
          ], 46, ["onMouseover"])) : createCommentVNode("", true)
        ];
      }
    }),
    _: 3
  }, _parent));
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/@nuxt/ui/dist/runtime/components/elements/Dropdown.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const columns = ref([
      {
        key: "id",
        label: "ID"
      },
      {
        key: "title",
        label: "Scholarship"
      },
      {
        key: "createdAt",
        label: "Applied At"
      },
      {
        key: "benefactor",
        label: "Benefactor"
      },
      {
        key: "status",
        label: "Status"
      }
    ]);
    const items = (row) => [
      [
        {
          label: "Approve",
          click: () => handleUpdateApplication(row.id, "ACCEPTED")
        },
        {
          label: "Reject",
          click: () => handleUpdateApplication(row.id, "REJECTED")
        }
      ]
    ];
    const headers = useRequestHeaders(["cookie"]);
    const { data: token } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/auth/token", { headers }, "$yRMfMhhWis")), __temp = await __temp, __restore(), __temp);
    const userId = (_a = token.value) == null ? void 0 : _a.id;
    const isAdmin = computed(() => {
      var _a2;
      return ((_a2 = token.value) == null ? void 0 : _a2.role) === "ADMIN";
    });
    const applications = ref([]);
    if (isAdmin.value) {
      const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/applications`, { method: "get" }, "$4Ay415M5AD")), __temp = await __temp, __restore(), __temp);
      applications.value = data.value.map((application) => ({
        id: application.id,
        user: application.user.name,
        title: application.scholarship.title,
        createdAt: application.createdAt,
        benefactor: application.scholarship.benefactor.name,
        status: application.application_status
      }));
      columns.value.push(
        {
          key: "user",
          label: "Applicant"
        },
        {
          key: "actions",
          label: "Actions"
        }
      );
    } else {
      const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/users/${userId}/applications`, {
        method: "get"
      }, "$BtMeJGbrH8")), __temp = await __temp, __restore(), __temp);
      applications.value = data.value.map((application) => ({
        id: application.id,
        title: application.scholarship.title,
        createdAt: application.createdAt,
        benefactor: application.scholarship.benefactor.name,
        status: application.application_status
      }));
    }
    const handleUpdateApplication = async (id, application_status) => {
      await useFetch(`/api/applications`, {
        method: "put",
        body: { id, application_status }
      }, "$kd9lfvyyKU");
      applications.value = applications.value.map((application) => {
        if (application.id === id) {
          application.status = application_status;
        }
        return application;
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UTable = __nuxt_component_0;
      const _component_UDropdown = __nuxt_component_1;
      const _component_UButton = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_UTable, {
        columns: unref(columns),
        rows: unref(applications)
      }, {
        "actions-data": withCtx(({ row }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(isAdmin)) {
              _push2(ssrRenderComponent(_component_UDropdown, {
                items: items(row)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UButton, {
                      color: "gray",
                      variant: "ghost",
                      icon: "i-heroicons-ellipsis-horizontal-20-solid"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UButton, {
                        color: "gray",
                        variant: "ghost",
                        icon: "i-heroicons-ellipsis-horizontal-20-solid"
                      })
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(isAdmin) ? (openBlock(), createBlock(_component_UDropdown, {
                key: 0,
                items: items(row)
              }, {
                default: withCtx(() => [
                  createVNode(_component_UButton, {
                    color: "gray",
                    variant: "ghost",
                    icon: "i-heroicons-ellipsis-horizontal-20-solid"
                  })
                ]),
                _: 2
              }, 1032, ["items"])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/applications/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-e16db606.mjs.map
