import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const {
    title,
    description,
    award,
    deadline,
    slug,
    categoryIds,
    benefactorId
  } = body;
  const mappedCategoryIds = categoryIds.map((category) => ({ id: category.id }));
  const scholarship = await prisma.scholarship.create({
    data: {
      title,
      description,
      award,
      deadline: new Date(deadline),
      slug,
      benefactor: {
        connect: {
          id: benefactorId
        }
      },
      categories: {
        connect: mappedCategoryIds
      }
    }
  });
  return scholarship;
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
