const client_manifest = {
  "_Button.498cac40.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Button.498cac40.js",
    "imports": [
      "_ui.config.87222996.js",
      "_nuxt-link.698b5797.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js"
    ]
  },
  "_ScholarshipStore.8d2bd42d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ScholarshipStore.8d2bd42d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js"
    ]
  },
  "_fetch.351e168d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fetch.351e168d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.698b5797.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.698b5797.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ui.config.87222996.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ui.config.87222996.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useFormGroup.1694c298.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFormGroup.1694c298.js",
    "imports": [
      "_ui.config.87222996.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.d3e5ec5a.js",
    "imports": [
      "_nuxt-link.698b5797.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.95c28eb4.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.4133b8cf.js",
    "imports": [
      "_nuxt-link.698b5797.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.95c28eb4.css": {
    "file": "error-404.95c28eb4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.e798523c.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.30465b44.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.e798523c.css": {
    "file": "error-500.e798523c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.d160ddd4.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/applications/create.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create.3308fc2f.js",
    "imports": [
      "_ui.config.87222996.js",
      "_useFormGroup.1694c298.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/applications/create.vue"
  },
  "pages/applications/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.08ff797f.js",
    "imports": [
      "_Button.498cac40.js",
      "_ui.config.87222996.js",
      "_useFormGroup.1694c298.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js",
      "_nuxt-link.698b5797.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/applications/index.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.573618ca.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.698b5797.js",
      "_ScholarshipStore.8d2bd42d.js",
      "_fetch.351e168d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.b2a85155.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  },
  "pages/scholarships/[scholarshipSlug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_scholarshipSlug_.3e15bdc8.js",
    "imports": [
      "_Button.498cac40.js",
      "_ScholarshipStore.8d2bd42d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.351e168d.js",
      "_ui.config.87222996.js",
      "_nuxt-link.698b5797.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/scholarships/[scholarshipSlug].vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
