import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_post = defineEventHandler(async (event) => {
  const { userId, scholarshipId } = await readBody(event);
  const application = await prisma.application.create({
    data: {
      user: {
        connect: {
          id: userId
        }
      },
      scholarship: {
        connect: {
          id: scholarshipId
        }
      }
    }
  });
  return application;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
