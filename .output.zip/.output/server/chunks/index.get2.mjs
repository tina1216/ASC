import { d as defineEventHandler } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_get = defineEventHandler(async (event) => {
  const benefactors = await prisma.benefactor.findMany();
  return benefactors;
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
