import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_put = defineEventHandler(async (event) => {
  const { id, application_status } = await readBody(event);
  const application = await prisma.application.update({
    where: {
      id
    },
    data: {
      application_status
    }
  });
  return application;
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
