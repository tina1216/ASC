import { e as eventHandler } from './nitro/node-server.mjs';
import { g as getToken } from './nuxtAuthHandler.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';
import 'next-auth/core';
import 'next-auth/jwt';

const token_get = eventHandler(async (event) => {
  const token = await getToken({ event });
  return token || "no token present";
});

export { token_get as default };
//# sourceMappingURL=token.get.mjs.map
