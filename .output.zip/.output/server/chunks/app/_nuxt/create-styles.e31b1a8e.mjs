const create_vue_vue_type_style_index_0_scoped_199ec80a_lang = "";

const createStyles_e31b1a8e = [create_vue_vue_type_style_index_0_scoped_199ec80a_lang, create_vue_vue_type_style_index_0_scoped_199ec80a_lang];

export { createStyles_e31b1a8e as default };
//# sourceMappingURL=create-styles.e31b1a8e.mjs.map
