import { d as defineEventHandler } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const applications_get = defineEventHandler(async (event) => {
  const applicationsByUser = await prisma.application.findMany({
    where: {
      user: {
        id: parseInt(event.context.params.userId)
      }
    },
    include: {
      scholarship: {
        include: {
          benefactor: true
        }
      }
    }
  });
  return applicationsByUser;
});

export { applications_get as default };
//# sourceMappingURL=applications.get.mjs.map
