import { d as defineEventHandler } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_get = defineEventHandler(async (event) => {
  const applications = await prisma.application.findMany({
    include: {
      user: true,
      scholarship: {
        include: {
          benefactor: true
        }
      }
    }
  });
  return applications;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
