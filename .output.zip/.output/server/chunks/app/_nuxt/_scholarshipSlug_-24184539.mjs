import { _ as __nuxt_component_0 } from './Button-bf5fb701.mjs';
import { u as useScholarshipStore } from './ScholarshipStore-b390cde1.mjs';
import { defineComponent, withAsyncContext, computed, ref, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { f as useRoute, d as useRequestHeaders, c as createError } from '../server.mjs';
import { u as useFetch } from './fetch-7843bd59.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import './nuxt-link-92569608.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';
import './ui.config-c2fe1eb9.mjs';
import 'tailwind-merge';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[scholarshipSlug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { scholarships } = ([__temp, __restore] = withAsyncContext(() => useScholarshipStore()), __temp = await __temp, __restore(), __temp);
    const route = useRoute();
    const scholarship = computed(() => {
      return scholarships.find(
        (scholarship2) => scholarship2.slug == route.params.scholarshipSlug
      );
    });
    const headers = useRequestHeaders(["cookie"]);
    const { data: token } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/auth/token", { headers }, "$FIQ7fbGtAF")), __temp = await __temp, __restore(), __temp);
    const userId = (_a = token.value) == null ? void 0 : _a.id;
    [__temp, __restore] = withAsyncContext(() => useFetch(
      `/api/users/${userId}/applications`,
      "$JwvL2pHiMG"
    )), __temp = await __temp, __restore();
    const isDisabled = ref(false);
    if (!scholarship.value) {
      throw createError({
        statusCode: 404,
        message: `Scholarship with the title of ${route.params.scholarshipSlug} does not exist`
      });
    }
    const handlePostApplication = async () => {
      const body = {
        scholarshipId: scholarship.value.id,
        userId
      };
      try {
        const { data, status, error } = await useFetch("/api/applications/", {
          method: "post",
          body
        }, "$4ZAoMlDsui");
        if (status.value === "success") {
          isDisabled.value = true;
        } else {
          console.error("Error updating scholarship status:", error);
        }
      } catch (err) {
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UButton = __nuxt_component_0;
      if (unref(scholarship)) {
        _push(`<div${ssrRenderAttrs(_attrs)}>${ssrInterpolate(unref(scholarship).title)} `);
        _push(ssrRenderComponent(_component_UButton, {
          onClick: handlePostApplication,
          disabled: unref(isDisabled)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Apply `);
            } else {
              return [
                createTextVNode(" Apply ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/scholarships/[scholarshipSlug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_scholarshipSlug_-24184539.mjs.map
