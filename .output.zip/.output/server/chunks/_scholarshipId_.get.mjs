import { d as defineEventHandler } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const _scholarshipId__get = defineEventHandler(async (event) => {
  const { scholarshipId } = event.context.params;
  const scholarship = await prisma.scholarship.findUnique({
    where: {
      id: parseInt(scholarshipId)
    }
  });
  return scholarship;
});

export { _scholarshipId__get as default };
//# sourceMappingURL=_scholarshipId_.get.mjs.map
