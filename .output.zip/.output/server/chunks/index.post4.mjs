import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, name } = body;
  const user = await prisma.user.create({
    data: {
      email,
      name
    }
  });
  return user;
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
