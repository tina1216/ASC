import { d as defineEventHandler } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const _userId__get = defineEventHandler(async (event) => {
  const { userId } = event.context.params;
  const user = await prisma.user.findUnique({
    where: {
      id: parseInt(userId)
    }
  });
  return user;
});

export { _userId__get as default };
//# sourceMappingURL=_userId_.get.mjs.map
