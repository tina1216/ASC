import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const index_post = defineEventHandler(async (event) => {
  const { name, description, logo, email } = await readBody(event);
  const benefactor = await prisma.benefactor.create({
    data: {
      name,
      description,
      logo,
      email
    }
  });
  return benefactor;
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
