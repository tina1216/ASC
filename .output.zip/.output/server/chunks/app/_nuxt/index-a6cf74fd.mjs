import { _ as __nuxt_component_0 } from './nuxt-link-92569608.mjs';
import { useSSRContext, defineComponent, withAsyncContext, computed, unref, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { u as useScholarshipStore } from './ScholarshipStore-b390cde1.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'tailwind-merge';
import './fetch-7843bd59.mjs';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ScholarshipCard",
  __ssrInlineRender: true,
  props: {
    scholarship: Object
  },
  setup(__props) {
    const randomNumber = Math.floor(Math.random() * 1e3);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-lg bg-gray-200 xl:aspect-h-8 xl:aspect-w-7"><img${ssrRenderAttr("src", `https://picsum.photos/${unref(randomNumber)}?grayscale`)} alt="" class="h-full w-full object-cover object-center group-hover:opacity-75"></div><h3 class="font-medium text-gray-900">${ssrInterpolate(__props.scholarship.title)}</h3></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ScholarshipCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { scholarships, fetchScholarships } = ([__temp, __restore] = withAsyncContext(() => useScholarshipStore()), __temp = await __temp, __restore(), __temp);
    fetchScholarships();
    const scholarshipList = computed(() => scholarships);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_ScholarshipCard = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><h2 class="mb-5 mt-5 font-bold">Scholarships</h2><ul class="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8"><!--[-->`);
      ssrRenderList(unref(scholarshipList), (scholarship) => {
        _push(`<li>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: scholarship.path
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_ScholarshipCard, { scholarship }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_ScholarshipCard, { scholarship }, null, 8, ["scholarship"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-a6cf74fd.mjs.map
