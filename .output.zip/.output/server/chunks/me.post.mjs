import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'requrl';
import 'node:fs';
import 'node:url';

const prisma = new PrismaClient();
const me_post = defineEventHandler(async (event) => {
  const { email, password } = await readBody(event);
  const user = await prisma.user.findUnique({
    where: {
      email
    }
  });
  if (password === (user == null ? void 0 : user.password)) {
    return user;
  } else {
    return null;
  }
});

export { me_post as default };
//# sourceMappingURL=me.post.mjs.map
