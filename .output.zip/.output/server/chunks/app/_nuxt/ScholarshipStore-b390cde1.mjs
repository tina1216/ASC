import { ref } from 'vue';
import { h as defineStore, c as createError } from '../server.mjs';
import { u as useFetch } from './fetch-7843bd59.mjs';

const useFetchScholarships = async () => {
  const { data, error } = await useFetch("/api/scholarships", "$TNfGfP0WmL");
  if (error.value) {
    console.error("Error fetching scholarships:", error);
    throw createError({
      ...error.value,
      statusMessage: "Unable to fetch scholarships"
    });
  }
  const scholarshipsWithPaths = data.value.map((scholarship) => ({
    ...scholarship,
    path: `/scholarships/${scholarship.slug}`
  }));
  return scholarshipsWithPaths;
};
const useScholarshipStore = defineStore("ScholarshipStore", () => {
  const scholarships = ref([]);
  async function fetchScholarships() {
    try {
      scholarships.value = await useFetchScholarships();
    } catch (err) {
      return err;
    }
  }
  return {
    scholarships,
    fetchScholarships
  };
});

export { useScholarshipStore as u };
//# sourceMappingURL=ScholarshipStore-b390cde1.mjs.map
